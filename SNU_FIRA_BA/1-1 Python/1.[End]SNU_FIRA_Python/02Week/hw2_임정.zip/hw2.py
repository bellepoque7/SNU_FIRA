#Assignment Number...: 2
#Student Name........: 임정
#File Name...........: hw2_임정
#Program Description.: 문자열 자료형의 변수를 생성, 슬라이싱 하는 방법을 배운다.

cellphone = 'Apple Iphone6S'          # 핸드폰 정보를 cellphone 문자열 자료형으로 저장
print(cellphone)                      # cellphone 변수 출력
company = cellphone[:5]               # 문자열 변수를 슬라이싱해 company 변수에 저장
print(company)                        # company 변수 출력
model = cellphone[6:]                 # 문자열 변수를 슬라이싱해 model 변수에 저장
print(model)                          # model 변수를 출력
print(type(company))                  # company 변수의 자료형을 출력
print(type(model))                    # model 변수의 자료형을 출력
print('It had been that way for days and days.\n'
' And then, just before the lunch bell rang, he walked into our class room.\n'
' Stepped through that door white and softly as the snow.')
